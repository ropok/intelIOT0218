var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"},
{text:"Data Fields",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"g",url:"functions.html#index_g"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"w",url:"functions.html#index_w"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"b",url:"functions_func.html#index_b"},
{text:"g",url:"functions_func.html#index_g"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"w",url:"functions_func.html#index_w"}]}]}]}]}
